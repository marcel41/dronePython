"""
Demo the Bebop indoors (sets small speeds and then flies just a small amount)
Note, the bebop will hurt your furniture if it hits it.  Even though this is a very small
amount of flying, be sure you are doing this in an open area and are prepared to catch!

"""

from pyparrot.Bebop import Bebop

bebop = Bebop(drone_type="Bebop2") # a Bebop object of a type Bebop2

# Performs a connection to the drone
print("connecting")
success = bebop.connect(10)
print(success)

# If connection is established, do the following:
if (success):
    # OPTIONAL: start a video stream
    print("turning on the video")
    #bebop.start_video_stream()

    print("sleeping")
    bebop.smart_sleep(2)

    bebop.ask_for_state_update()

    # Performs a takeoff
    bebop.safe_takeoff(10)
    print(bebop.sensors.flying_state)
    # set safe indoor parameters
    bebop.set_max_tilt(5) # 5 - very slow, 30 - very fast (in degrees)
    bebop.set_max_vertical_speed(1) # between 0.5 and 2.5 m/s
    bebop.set_max_altitude(1) # between 0.5 and 150 m

    # trying out the new hull protector parameters - set to 1 for a hull protection and 0 without protection
    bebop.set_hull_protection(1)

    # Drone flies for <duration> of seconds. Each value ranges from -100 to 100,
    # which is a percentage and direction of the max_tilt or max_vertical.
    # Roll, pitch and yaw - self-explanatory.
    print("Flying direct: Slow move for indoors")
    #bebop.fly_direct(roll=0, pitch=20, yaw=0, vertical_movement=0, duration=2)
    print(bebop.sensors.flying_state)
    # Stops flying, prepares for a landing
    bebop.smart_sleep(5)
    print(bebop.sensors.flying_state)
    # The drone lands *safely*
    bebop.safe_land(10)
    print(bebop.sensors.flying_state)

    # Performance done

    print("DONE - disconnecting")
    # OPTIONAL: stop video streaming
    #bebop.stop_video_stream()
    bebop.smart_sleep(5)
    print(bebop.sensors.battery)
    # We disconnect from the drone
    bebop.disconnect()
