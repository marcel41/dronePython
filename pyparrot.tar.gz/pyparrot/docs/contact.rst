.. title:: Contact the pyparrot developers

.. contact:

Contact the pyparrot developers
===============================

Contribute
----------

We welcome your contributions via bug report or pull request.

* Issue Tracker: `<https://github.com/amymcgovern/pyparrot/issues>`_
* Pull requests: `<https://github.com/amymcgovern/pyparrot/pulls>`_
* Source Code:  `<https://github.com/amymcgovern/pyparrot>`_

Support
-------
If you are having issues, please let us know by reporting issues on GitHub using the issue
tracker `<https://github.com/amymcgovern/pyparrot/issues>`_.
